#!/usr/bin/octave -q


load("data/mini/tr.dat");
load("data/mini/trlabels.dat");

C = 1000;

res = svmtrain(trlabels, tr, "-t 0 -c 1000");

#plot(tr(trlabels==1,1),tr(trlabels==1,2),"or",tr(trlabels==2,1), tr(trlabels==2,2),"ob", tr(res.sv_indices,1),tr(res.sv_indices,2), "xg")

multLagrange = res.sv_coef
vectoresSoporte = res.sv_indices; #res.SVs
indices = vectoresSoporte;
teta1 = tr(indices,1)' * multLagrange #clase*vectoressoporte*multlagrange
teta2 = tr(indices,2)' * multLagrange

teta = tr(indices,:)' * multLagrange


for i = 1:rows(indices)
    if abs(multLagrange(i)) > 0 && abs(multLagrange(i)) < C
        teta0 = trlabels(indices(i)) - teta' * tr(indices(i),:)'
    	break;
    endif
endfor

umbral = teta0

margen = 2 / sum(sqrt(teta))

signos = []
for i = 1:rows(trlabels)
    if trlabels(i) == 1
        signos(i) = 1;
    else
        signos(i) = -1;
    endif
endfor

tolerancias = diag(1 - signos' * ([teta1, teta2] * tr' + teta0))(indices,:)

vecMAL = find(abs(tolerancias)>0.001)

bias = -(umbral/teta2);
%Recta
X = [0:0.01:7];
Y = -teta(1)/teta(2)*X+bias;
%Parametros rectas frontera. Mismo gradiente.
biasFrontera1=-((umbral-1)/teta(2));
biasFrontera2=-((umbral+1)/teta(2));

YFrontera1 = -teta(1)/teta(2)*X+biasFrontera1;
YFrontera2 = -teta(1)/teta(2)*X+biasFrontera2;

plot(X,Y,X,YFrontera1,X,YFrontera2,
    tr(trlabels==1,1), tr(trlabels==1,2),'sr',
    tr(trlabels==2,1), tr(trlabels==2,2),'ob',
    res.SVs(vecMAL, 1), res.SVs(vecMAL, 2),'x'
);



